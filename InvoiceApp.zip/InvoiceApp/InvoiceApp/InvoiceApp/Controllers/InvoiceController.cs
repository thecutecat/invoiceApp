﻿using InvoiceApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;

namespace InvoiceApp.Controllers
{
    public class InvoiceController : Controller
    {
        InvoiceDBContext DB = new InvoiceDBContext();
        // GET: Invoice
        public ActionResult Index()
        {
            var Invoices = DB.tblInvoice.Include("invoicesDetail").ToList();
            return View(Invoices);
        }

        public ActionResult Detail(int id)
        {
            var invoice = DB.tblInvoice.SingleOrDefault(obj => obj.invoiceID == id);
            ViewBag.Invoicedetail = DB.tblInvoicesDetail.Where(obj => obj.invoiceID == id).ToList();

            return View(invoice);
        }

        // GET: Invoice/Details/5
        public ActionResult Details(int id=1)
        {
            String query = @"SELECT i.nomerInvoice, namaBarang, namaLangganan, jumlahBarang, unitPrice, tanggalInvoice, jumlahBarang* unitPrice AS subTotal
                            FROM[dbo].[tblInvoicesDetail] d
                             LEFT JOIN dbo.tblInvoice i ON i.invoiceID = d.invoiceID
                             LEFT JOIN dbo.tblBarang b on b.barangID = d.barangID
                             LEFT JOIN dbo.tblLangganan l on l.langgananID = i.langgananID
                            WHERE d.invoiceID = " + id;
            string strcon = ConfigurationManager.ConnectionStrings["InvoiceDBContext"].ConnectionString;
            SqlConnection conn = new SqlConnection(strcon);
            conn.Open();

            SqlCommand cmd = new SqlCommand(query, conn);
            var reader = cmd.ExecuteReader();
            List<Dictionary<string, string>> myList = new List<Dictionary<string, string>>();
            int allTotal = 0;

            while (reader.Read())
            {
                var myData = new Dictionary<string, string>();
                myData["nomerInvoice"] = reader[0].ToString();
                myData["namaBarang"] = reader[1].ToString();
                myData["namaLangganan"] = reader[2].ToString();
                myData["jumlahBarang"] = reader[3].ToString();
                myData["unitPrice"] = reader[4].ToString();
                myData["tanggalInvoice"] = reader[5].ToString();//Convert.ToDateTime(reader[5]).ToString("yyyy-MM-dd HH:mm:ss");
                myData["subTotal"] = reader[6].ToString();

                myList.Add(myData);
                allTotal = allTotal + Convert.ToInt32(reader[6].ToString());
            }

            ViewBag.invoiceDetails = myList;
            ViewBag.AllTotal = allTotal;

            return View();
        }

        // GET: Invoice/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Invoice/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Invoice/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Invoice/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Invoice/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Invoice/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
