namespace InvoiceApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.tblBarang",
                c => new
                    {
                        barangID = c.Int(nullable: false, identity: true),
                        namaBarang = c.String(),
                        unitPrice = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.barangID);
            
            CreateTable(
                "dbo.tblInvoicesDetail",
                c => new
                    {
                        invoiceDetailID = c.Int(nullable: false, identity: true),
                        jumlahBarang = c.Int(nullable: false),
                        invoiceID = c.Int(nullable: false),
                        barangID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.invoiceDetailID)
                .ForeignKey("dbo.tblBarang", t => t.barangID, cascadeDelete: true)
                .ForeignKey("dbo.tblInvoice", t => t.invoiceID, cascadeDelete: true)
                .Index(t => t.invoiceID)
                .Index(t => t.barangID);
            
            CreateTable(
                "dbo.tblInvoice",
                c => new
                    {
                        invoiceID = c.Int(nullable: false, identity: true),
                        nomerInvoice = c.String(),
                        langgananID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.invoiceID)
                .ForeignKey("dbo.tblLangganan", t => t.langgananID, cascadeDelete: true)
                .Index(t => t.langgananID);
            
            CreateTable(
                "dbo.tblLangganan",
                c => new
                    {
                        langgananID = c.Int(nullable: false, identity: true),
                        namaLangganan = c.String(),
                    })
                .PrimaryKey(t => t.langgananID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.tblInvoice", "langgananID", "dbo.tblLangganan");
            DropForeignKey("dbo.tblInvoicesDetail", "invoiceID", "dbo.tblInvoice");
            DropForeignKey("dbo.tblInvoicesDetail", "barangID", "dbo.tblBarang");
            DropIndex("dbo.tblInvoice", new[] { "langgananID" });
            DropIndex("dbo.tblInvoicesDetail", new[] { "barangID" });
            DropIndex("dbo.tblInvoicesDetail", new[] { "invoiceID" });
            DropTable("dbo.tblLangganan");
            DropTable("dbo.tblInvoice");
            DropTable("dbo.tblInvoicesDetail");
            DropTable("dbo.tblBarang");
        }
    }
}
