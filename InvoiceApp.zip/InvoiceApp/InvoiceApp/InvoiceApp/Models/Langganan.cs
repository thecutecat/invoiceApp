﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InvoiceApp.Models
{
    [Table("tblLangganan")]
    public class Langganan
    {
        [Key]
        public int langgananID { get; set; }
        public string namaLangganan { get; set; }

        //public virtual List<Barang> barang { get; set; }
        public virtual List<Invoice> invoice { get; set; }
    }
}