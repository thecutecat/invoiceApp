﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InvoiceApp.Models
{
    [Table("tblBarang")]
    public class Barang
    {
        [Key]
        public int barangID { get; set; }
        public string namaBarang { get; set; }
        public double unitPrice { get; set; }

        //public List<Langganan> langganan { get; set; }
        public List<InvoicesDetail> invoicesDetail { get; set; }
    }
}