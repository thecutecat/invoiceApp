﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InvoiceApp.Models
{
    [Table("tblInvoicesDetail")]
    public class InvoicesDetail
    {
        [Key]
        public int invoiceDetailID { get; set; }
        public int jumlahBarang { get; set; }
        
        public int invoiceID { get; set; }
        public int barangID { get; set; }
        public Barang barang { get; set; }
    }
}