﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace InvoiceApp.Models
{
    [Table("tblInvoice")]
    public class Invoice
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int invoiceID { get; set; }
        public string nomerInvoice { get; set; }
        [DataType("Date")]
        public string tanggalInvoice { get; set; }

        public int langgananID { get; set; }
        public Langganan langganan { get; set; }
        public List<InvoicesDetail> invoicesDetail { get; set; }
    }
}