﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web; 

namespace InvoiceApp.Models
{
    public class InvoiceDBContext : DbContext
    {
        public virtual DbSet<Langganan> tblLangganan { get; set; }
        public virtual DbSet<Barang> tblBarang { get; set; }
        public virtual DbSet<Invoice> tblInvoice { get; set; }
        public virtual DbSet<InvoicesDetail> tblInvoicesDetail { get; set; }
    }
}